# ConnectFour

If running ConnectFour and you select online, the server must be running first.
The default port for the server is 8000.
