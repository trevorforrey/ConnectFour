# ConnectFour

If running ConnectFour and you choose to play online, the server must be running first, so java Server file, then from there you can run the game and connect the ports with your IP address entered in through 2 seperate terminal windows or computers.  
The default port for the server is 8000. You must enter the same IP address as used on the Server. There is only animation for hovering the mouse when the Chips is attempting to be placed. It was not working with the given deadline, to get animations rendering for the chip dropping ONLY for online, every other game mode works it flawlessly.

Also, run the program from a Desktop Computer so the game will display it's full contents, the game is intended to run on a desktop computer, not on a laptop with 13 inches diagonal.

The screen shots resemble the test cases on the ConnectFour TestLog picture, 
:)